<?php
include("db.php");
if (isset($_GET['id'])){ 
    $id=$_GET['id'];
    $esborra="delete from grups where id=$id";
    $resultat=mysqli_query($connexio,$esborra);
    if (!$resultat){
        die ("Esborrar erròni");
    }
    $_SESSION['missatge'] = "Grup Esborrat Correctament";
	$_SESSION['tipus_missatge'] = 'danger'; // Color verd pel missatge (succes és un verd a Bootstrap)
    header("Location: index.php");//redirecciona a index.php
}
?>